// App.js
import React from 'react';
//import Notearea from './component/Notearea.jsx';
//import Slidebar from './component/Slidebar.jsx';
import Home from './component/Home.jsx';


function App() {
    return (
        <div className="App" style={{marginTop:"0%"}}>
        <Home/>
        </div>
      
      );
     
    
}

export default App;
 